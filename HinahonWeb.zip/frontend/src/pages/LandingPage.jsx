import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";
import Footer from "../components/Footer";
import { checkVideoLinkAccess, getConsultationStatusBadge } from "../utils/consultationTimeUtils";
import logo from "../assets/hinahon.png";
import logo1 from "../assets/lpub.png";
import logo2 from "../assets/catc.png";
import bgImage2 from "../assets/bg-lotus.jpg";
import bgImage3 from "../assets/bg-animated.gif";
import bgVideo from "../assets/bg-animated.mp4";
import AIAssistantFloating from "../components/AIAssistantFloating";
import "../styles.css";
import "../styles2.css";
import ResponsiveHeader from "../components/ResponsiveHeader";

export default function LandingPage({ session, setSession }) {
  const navigate = useNavigate();
  const user = session?.user;

  const [selectedEmotion, setSelectedEmotion] = useState(null);
  const [allConsultations, setAllConsultations] = useState([]);
  const [displayedConsultations, setDisplayedConsultations] = useState([]);
  const [loadingConsultations, setLoadingConsultations] = useState(true);
  const [userName, setUserName] = useState("");
  const [hasMore, setHasMore] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [showBookingsModal, setShowBookingsModal] = useState(false);
  const [showConsentModal, setShowConsentModal] = useState(false);
  const [pendingEmotion, setPendingEmotion] = useState(null);
  const [hasConsented, setHasConsented] = useState(false);
  const [hasOngoingConsultation, setHasOngoingConsultation] = useState(false);

  const observerTarget = useRef(null);
  const emotionsGridRef = useRef(null); // <-- ref to detect outside clicks
  const ITEMS_PER_PAGE = 3;

  useEffect(() => {
    if (user) {
      fetchUserName();
      fetchConsultations();
      checkConsentStatus();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // Deselect emotion when clicking outside the emotions grid
  useEffect(() => {
    function handleClickOutside(e) {
      try {
        if (emotionsGridRef.current && !emotionsGridRef.current.contains(e.target)) {
          setSelectedEmotion(null);
        }
      } catch (err) {
        // ignore
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("touchstart", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("touchstart", handleClickOutside);
    };
  }, []);

  // Setup intersection observer for infinite scroll in modal
  useEffect(() => {
    if (!showBookingsModal) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoadingMore) {
          loadMoreConsultations();
        }
      },
      { threshold: 0.1 }
    );

    const currentTarget = observerTarget.current;
    if (currentTarget) {
      observer.observe(currentTarget);
    }

    return () => {
      if (currentTarget) {
        observer.unobserve(currentTarget);
      }
    };
  }, [showBookingsModal, hasMore, isLoadingMore, displayedConsultations.length]);

  const fetchUserName = async () => {
    try {
      const { data, error } = await supabase.from("users").select("name").eq("id", user.id).single();
      if (error) throw error;
      setUserName(data?.name || user.email?.split("@")[0] || "User");
    } catch (err) {
      console.error("Error fetching user name:", err);
      setUserName(user.email?.split("@")[0] || "User");
    }
  };

  const checkConsentStatus = () => {
    try {
      const consentKey = `tele_counseling_consent_${user.id}`;
      const consentStatus = localStorage.getItem(consentKey);
      if (consentStatus === "accepted") {
        setHasConsented(true);
      }
    } catch (err) {
      console.error("Error checking consent status:", err);
    }
  };

  const fetchConsultations = async () => {
    try {
      const { data, error } = await supabase
        .from("consultations")
        .select(`
          id,
          date,
          time,
          status,
          video_link,
          reason,
          rejection_reason,
          meeting_ended,
          start_time,
          end_time,
          availability_id,
          counselor:counselor_id(name, email)
        `)
        .eq("student_id", user.id)
        .order("date", { ascending: true })
        .order("time", { ascending: true });

      if (error) throw error;

      const sortedConsultations = prioritizeConsultations(data || []);

      // Check if there's any ongoing consultation
      const hasOngoing = sortedConsultations.some((consultation) => {
        const accessInfo = checkVideoLinkAccess(consultation.date, consultation.time);
        return (
          consultation.status === "accepted" &&
          !consultation.meeting_ended &&
          accessInfo.canAccess &&
          accessInfo.reason === "active"
        );
      });
      setHasOngoingConsultation(hasOngoing);

      setAllConsultations(sortedConsultations);
      setDisplayedConsultations(sortedConsultations.slice(0, ITEMS_PER_PAGE));
      setHasMore(sortedConsultations.length > ITEMS_PER_PAGE);
    } catch (err) {
      console.error("Error fetching consultations:", err);
    } finally {
      setLoadingConsultations(false);
    }
  };

  const handleCancelConsultation = async (consultationId, availabilityId) => {
    if (!window.confirm("Are you sure you want to cancel this consultation request? This action cannot be undone.")) {
      return;
    }

    try {
      console.log("Cancelling consultation:", consultationId);

      // Update consultation status to cancelled
      const { error: consultationError } = await supabase
        .from("consultations")
        .update({ status: "cancelled" })
        .eq("id", consultationId)
        .eq("student_id", user.id) // Security: ensure only the student can cancel their own
        .eq("status", "pending"); // Only allow cancelling pending consultations

      if (consultationError) {
        console.error("Error updating consultation:", consultationError);
        throw consultationError;
      }

      console.log("✅ Consultation status updated to cancelled");

      // Free up the availability slot if it exists
      if (availabilityId) {
        const { error: availabilityError } = await supabase.from("availability").update({ is_booked: false }).eq("id", availabilityId);
        if (availabilityError) {
          console.warn("⚠️ Warning: Failed to free up availability slot:", availabilityError);
        } else {
          console.log("✅ Availability slot freed up");
        }
      }

      // Refresh consultations list
      await fetchConsultations();

      alert("✅ Consultation request cancelled successfully");
    } catch (err) {
      console.error("❌ Error cancelling consultation:", err);
      alert("Failed to cancel consultation: " + err.message);
    }
  };

  const prioritizeConsultations = (consultations) => {
    const categorized = consultations.map((consultation) => {
      const accessInfo = checkVideoLinkAccess(consultation.date, consultation.time);
      const consultDate = new Date(`${consultation.date}T${consultation.time}`);

      let priority = 0;
      let category = "";

      if (consultation.status === "accepted" && !consultation.meeting_ended && accessInfo.canAccess && accessInfo.reason === "active") {
        priority = 1;
        category = "ongoing";
      } else if (consultation.status === "pending") {
        priority = 2;
        category = "pending";
      } else if (consultation.status === "accepted" && !consultation.meeting_ended && accessInfo.reason === "not_started") {
        priority = 3;
        category = "upcoming";
      } else if (consultation.status === "cancelled") {
        priority = 6;
        category = "cancelled";
      } else if (consultation.meeting_ended || consultation.status === "completed") {
        priority = 5;
        category = "completed";
      } else {
        priority = 4;
        category = "past";
      }

      return { ...consultation, priority, category, consultDate, accessInfo };
    });

    // Sort by date descending (newest first)
    return categorized.sort((a, b) => {
      return b.consultDate - a.consultDate;
    });
  };

  const loadMoreConsultations = () => {
    if (isLoadingMore) return;

    setIsLoadingMore(true);

    setTimeout(() => {
      const currentLength = displayedConsultations.length;
      const nextBatch = allConsultations.slice(currentLength, currentLength + ITEMS_PER_PAGE);

      setDisplayedConsultations((prev) => [...prev, ...nextBatch]);
      setHasMore(currentLength + ITEMS_PER_PAGE < allConsultations.length);
      setIsLoadingMore(false);
    }, 300);
  };

  async function handleSignOut() {
    await supabase.auth.signOut();
    setSession(null);
    navigate("/");
  }

  const emotions = [
    { label: "Happy", icon: "🙂", tag: "happy" },
    { label: "Sad", icon: "😢", tag: "sad" },
    { label: "Angry", icon: "😡", tag: "angry" },
    { label: "Scared", icon: "😨", tag: "scared" },
    { label: "Worried", icon: "😟", tag: "worried" },
    { label: "Tired", icon: "😴", tag: "tired" },
    { label: "Disgusted", icon: "🤢", tag: "disgusted" },
    { label: "Overwhelmed", icon: "😵", tag: "overwhelmed" },
  ];

  // Toggle selection if same emotion clicked, otherwise select
  const handleEmotionClick = (label) => {
    setSelectedEmotion((prev) => (prev === label ? null : label));
  };

  // Also allow keyboard toggling (Enter / Space) for accessibility
  const handleEmotionKeyDown = (e, label) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      handleEmotionClick(label);
    }
  };

  function handleBookAppointment() {
    const emotion = emotions.find((e) => e.label === selectedEmotion);
    const emotionTag = emotion?.tag || "general";

    // Check if user has already consented
    if (hasConsented) {
      // Skip consent modal and go directly to booking
      navigate("/booking", { state: { emotion: emotionTag } });
    } else {
      // Show consent modal for first-time users
      setPendingEmotion(emotionTag);
      setShowConsentModal(true);
    }
  }

  function handleConsentAccept() {
    try {
      // Save consent to localStorage
      const consentKey = `tele_counseling_consent_${user.id}`;
      localStorage.setItem(consentKey, "accepted");
      setHasConsented(true);
    } catch (err) {
      console.error("Error saving consent:", err);
    }

    setShowConsentModal(false);
    navigate("/booking", { state: { emotion: pendingEmotion } });
  }

  function handleConsentReject() {
    setShowConsentModal(false);
    setPendingEmotion(null);
  }

  function handleReadArticles() {
    const emotion = emotions.find((e) => e.label === selectedEmotion);
    const emotionTag = emotion?.tag || "happy";
    navigate(`/articles/${emotionTag}`);
  }

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const formatTime = (timeStr) => {
    const [hours, minutes] = timeStr.split(":");
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? "PM" : "AM";
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getStatusColor = (status, date, time) => {
    return getConsultationStatusBadge(status, date, time);
  };

  return (
    <div
      className="landing-root"
      style={{
        position: "relative",
        minHeight: "100vh",
        overflow: "hidden",
      }}
    >
      <div>
        <video
          key={bgVideo}
          autoPlay
          loop
          muted
          playsInline
          poster={bgImage3}
          aria-hidden="true"
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            width: "145%",
            height: "115%",
            transform: "translate(-50%, -50%) scale(0.78)",
            transformOrigin: "center center",
            objectFit: "cover",
            zIndex: 0,
          }}
        >
          <source src={bgVideo} type="video/mp4" />
        </video>

        <div />
      </div>

      <div style={{ position: "relative", zIndex: 2 }}>
        <style>{`
          /* One-time entrance for header title */
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(8px) scale(0.99); filter: blur(2px); }
            to { opacity: 1; transform: translateY(0) scale(1); filter: blur(0); }
          }
          /* Continuous float for the title */

          .animated-welcome {
            display: inline-block;
            will-change: transform, opacity;
            text-shadow: 0 6px 18px rgba(0,0,0,0.18);
            background: linear-gradient(90deg, #c71e70, #41c6b7ff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
          }

          /* Emotion idle animation (subtle float + gentle glow) */
          @keyframes emotionFloat {
            0% { transform: translateY(0) scale(1); }
            25% { transform: translateY(-3px) scale(1.03); }
            50% { transform: translateY(0) scale(1); }
            75% { transform: translateY(-2px) scale(1.02); }
            100% { transform: translateY(0) scale(1); }
          }
          @keyframes emotionGlow {
            0% { box-shadow: 0 0 0px rgba(199,30,112,0.0); }
            50% { box-shadow: 0 10px 24px rgba(199,30,112,0.08); }
            100% { box-shadow: 0 0 0px rgba(199,30,112,0.0); }
          }

          /* New: rotating gradient ring keyframes */
          @keyframes spin {
            to { transform: rotate(360deg); }
          }

          /* Teal color variable */
          :root { --teal: #00bfa5; }

          /* Ensure the selected emotion still has the float/glow + rotating border ring */
          .emotion.selected .emotion-circle, .emotion:focus-visible .emotion-circle {
            animation: emotionFloat 3.6s ease-in-out infinite, emotionGlow 3.6s ease-in-out infinite;
            will-change: transform, box-shadow;
          }

          :root {
            --teal: #00bfa5;
            /* default values you can tweak */
            --ring-gap: 5px;        /* distance between the circle and the ring */
            --ring-thickness: -1px;  /* <-- change this to control the ring thickness */
          }

          .emotion .emotion-circle {
            position: relative;
            z-index: 1;
}
          /* Base circle style */
          .emotion .emotion-circle {
            width: 52px;
            height: 52px;
            border-radius: 999px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255,255,255,0.85);
            box-shadow: 0 4px 12px rgba(2, 6, 23, 0.08);
            border: 1px solid rgba(0,0,0,0.06);
            transition: transform 200ms ease, border-color 200ms ease, background 200ms ease, box-shadow 200ms ease;
            font-size: 22px;
            user-select: none;
            position: relative; /* for pseudo-element ring */
            z-index: 0;
          }

          /* Pseudo-element to create the rotating gradient ring around the circle.
             This uses a conic-gradient background and a radial mask to make a donut (ring).
             The pseudo-element sits behind the main circle (z-index:0) while the circle content stays above it.
          */
          .emotion.selected .emotion-circle::before {
            content: "";
            position: absolute;
            inset: calc(-1 * (var(--ring-gap) + var(--ring-thickness)));
            border-radius: 999px;
            background: conic-gradient(from 0deg, var(--teal), #41c6b7, #1e91c7ff, var(--teal));
            -webkit-mask: radial-gradient(farthest-side, transparent calc(100% - 10px), black calc(100% - 8px));
            mask: radial-gradient(farthest-side, transparent calc(100% - 2.5px), black calc(100% - 1px));
            pointer-events: none;
            z-index: 0;
            animation: spin 2.6s linear infinite;
            will-change: transform;
            box-shadow: 0 4px 12px rgba(2, 6, 23, 0.08);
            filter: drop-shadow(0 6px 16px rgba(0, 191, 166, 0.69));
          }

          /* subtle teal glow on selected circle */
          .emotion.selected .emotion-circle {
            box-shadow: 0 8px 28px rgba(0,191,165,0.12);
          }

          /* Make sure the pseudo-element ring doesn't show on non-selected states */
          .emotion .emotion-circle::before { display: none; }

          /* Show ring only for selected (so the display rule above is safe) */
          .emotion.selected .emotion-circle::before { display: block; }

          @media (prefers-reduced-motion: reduce) {
            .emotion.selected .emotion-circle, .emotion:focus-visible .emotion-circle { animation: none; transform: none !important; box-shadow: 0 8px 20px rgba(0,0,0,0.08) !important; }
            .animated-welcome { animation: none; transform: none; opacity: 1; }
            .emotion.selected .emotion-circle::before { animation: none; }
          }

          /* small adjustments for modal and buttons readability on top of video */
          .modal-container, .modal-content, .consultation-card {
            background: rgba(255,255,255,0.98);
          }
          .modal-overlay {
            backdrop-filter: blur(4px);
          }

          /* ongoing indicator */
          .ongoing-indicator {
            display: inline-flex;
            gap: 8px;
            align-items: center;
            margin-left: 10px;
            font-size: 12px;
            background: rgba(255,255,255,0.08);
            padding: 6px 8px;
            border-radius: 999px;
            color: #fff;
            border: 1px solid rgba(255,255,255,0.12);
            box-shadow: 0 4px 12px rgba(0,0,0,0.12);
          }
          .pulse-dot {
            width: 8px;
            height: 8px;
            border-radius: 999px;
            background: #ff5a5f;
            box-shadow: 0 0 8px rgba(255,90,95,0.6);
            animation: pulse 1.6s infinite;
          }
          @keyframes pulse {
            0% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.4); opacity: 0.6; }
            100% { transform: scale(1); opacity: 1; }
          }

          /* ensure hero content remains readable on small screens */
          @media (max-width: 768px) {
            .hero-note { margin-left: 16px !important; font-size: 14px; }
            .brand-display { font-size: 28px; margin-left: 16px !important; }
            .greet-small { margin-left: 16px; font-size: 14px; }
            .emotions-grid { gap: 8px; }
            .emotion-circle { width: 48px; height: 48px; font-size: 20px; }
            .post-actions { padding: 12px 16px; }
            .action-buttons { display: flex; flex-direction: column; gap: 8px; }
            .btn-action { width: 100%; }
          }
        `}</style>

        <ResponsiveHeader session={session} title="A Mental Health Booking Solution" showNavigation={true} showBackButton={false} />

        <main className="landing-hero">
          <div className="hero-inner">
            <div className="greeting">
              <div className="greet-small">
                Hello, <span style={{ color: "#c71e70ff" }}>{userName}</span> !
              </div>

              <h2 className="brand-display" style={{ marginTop: 10, marginLeft: 15 }}>
                <span className="animated-welcome">Welcome Back!</span>
              </h2>

              <p className="hero-note" style={{ marginLeft: 30 }}>
                We're glad you're here! This is your safe space to reflect and feel supported.
              </p>

              <div className="emotion-section">
                <div className="feeling-ask" style={{ marginRight: 25 }}>
                  How are you feeling today?
                </div>

                <div className="emotions-grid" role="list" aria-label="Emotions" ref={emotionsGridRef}>
                  {emotions.map((e) => (
                    <button
                      key={e.label}
                      className={`emotion ${selectedEmotion === e.label ? "selected" : ""}`}
                      type="button"
                      onClick={() => handleEmotionClick(e.label)}
                      onKeyDown={(ev) => handleEmotionKeyDown(ev, e.label)}
                      aria-pressed={selectedEmotion === e.label}
                      aria-label={`Select ${e.label} emotion`}
                    >
                      <div className="emotion-circle">{e.icon}</div>
                      <div className="emotion-label">{e.label}</div>
                    </button>
                  ))}
                </div>

                <div className="post-actions">
                  {selectedEmotion && (
                    <p className="selected-note" style={{ marginRight: 35 }}>
                      You're feeling{""}
                      <strong
                        className="selected-emotion-inline"
                        style={{
                          background: "linear-gradient(90deg, #c71e70, #41c6b7)",
                          WebkitBackgroundClip: "text",
                          backgroundClip: "text",
                          color: "transparent",
                          fontWeight: 700,
                          marginLeft: 6,
                          marginRight: 6,
                        }}
                      >
                        {selectedEmotion}
                      </strong>
                      . Take a breath — what feels right for you next?
                    </p>
                  )}
                  <div className="action-buttons" style={{ marginRight: 35 }}>
                    <button className="btn-action view-bookings" onClick={() => setShowBookingsModal(true)}>
                      📋 Check my Bookings
                      {hasOngoingConsultation && (
                        <span className="ongoing-indicator">
                          <span className="pulse-dot" />
                          ACTIVE NOW
                        </span>
                      )}
                    </button>

                    {selectedEmotion && (
                      <>
                        <button className="btn-action primary" onClick={handleBookAppointment}>
                          📅 Talk to Someone
                        </button>
                        <button className="btn-action secondary" onClick={handleReadArticles}>
                          📖 Find Helpful Reads
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>

        <Footer />

        {/* Bookings Modal */}
        {showBookingsModal && (
          <div className="modal-overlay" onClick={() => setShowBookingsModal(false)}>
            <div className="modal-container" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h3>💬 Your Consultations</h3>
                <button className="modal-close" onClick={() => setShowBookingsModal(false)} aria-label="Close modal">
                  ✕
                </button>
              </div>

              <div className="modal-content">
                {loadingConsultations ? (
                  <p style={{ color: "#666", fontSize: "14px", textAlign: "center", padding: "20px" }}>Loading...</p>
                ) : allConsultations.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "40px 20px", color: "#666" }}>
                    <div style={{ fontSize: "48px", marginBottom: "16px" }}>📅</div>
                    <p style={{ fontSize: "16px", marginBottom: "8px", fontWeight: "500" }}>No consultations yet</p>
                    <p style={{ fontSize: "14px", color: "#999" }}>Book your first appointment to get started!</p>
                  </div>
                ) : (
                  <>
                    <div className="consultations-list">
                      {displayedConsultations.map((consultation) => {
                        const statusInfo = getStatusColor(consultation.status, consultation.date, consultation.time);
                        const accessInfo = consultation.accessInfo || checkVideoLinkAccess(consultation.date, consultation.time);

                        return (
                          <div key={consultation.id} className="consultation-card">
                            <div className="consultation-header">
                              <div>
                                <div className="counselor-name">{consultation.counselor?.name || consultation.counselor?.email || "Counselor"}</div>
                                <div className="consultation-datetime">
                                  📅 {formatDate(consultation.date)} • 🕐 {formatTime(consultation.time)}
                                </div>
                              </div>
                              <span className="status-badge" style={{ backgroundColor: statusInfo.bg, color: statusInfo.color }}>
                                {statusInfo.text}
                              </span>
                            </div>

                            {consultation.reason && (
                              <div className="consultation-reason">
                                <p className="reason-label">Reason:</p>
                                <p className="reason-text">{consultation.reason}</p>
                              </div>
                            )}

                            {/* ONLY apply the new "Occupied" status rendering here in the modal */}
                            {consultation.status === "occupied" && (
                              <p className="access-message error">⚠️ This time slot is already booked by another student.</p>
                            )}

                            {consultation.status === "rejected" && consultation.rejection_reason && (
                              <div className="rejection-reason">
                                <p className="reason-label">Reason:</p>
                                <p className="reason-text">{consultation.rejection_reason}</p>
                              </div>
                            )}

                            {consultation.status === "accepted" && consultation.video_link && !consultation.meeting_ended && (
                              <>
                                {accessInfo.canAccess ? (
                                  <div>
                                    <a href={consultation.video_link} target="_blank" rel="noopener noreferrer" className="video-link-button">
                                      🎥 Join Video Call
                                    </a>
                                    <p className="access-message success">{accessInfo.message}</p>
                                  </div>
                                ) : (
                                  <div>
                                    <button disabled className="video-link-button disabled">
                                      🎥 Join Video Call
                                    </button>
                                    <p className={`access-message ${accessInfo.reason === "expired" ? "error" : "warning"}`}>{accessInfo.message}</p>
                                  </div>
                                )}
                              </>
                            )}

                            {consultation.status === "pending" && (
                              <>
                                <p className="access-message warning">Waiting for counselor to accept...</p>
                                <button onClick={() => handleCancelConsultation(consultation.id, consultation.availability_id)} className="cancel-consultation-button">
                                  ❌ Cancel Request
                                </button>
                              </>
                            )}

                            {consultation.status === "cancelled" && <p className="access-message error">❌ You cancelled this consultation</p>}

                            {consultation.meeting_ended && <p className="access-message completed">✅ Meeting completed</p>}
                          </div>
                        );
                      })}
                    </div>

                    {hasMore && (
                      <div ref={observerTarget} className="load-more-trigger">
                        {isLoadingMore ? (
                          <div className="loading-spinner">
                            <div className="spinner" />
                            Loading more...
                          </div>
                        ) : (
                          "Scroll for more"
                        )}
                      </div>
                    )}

                    {!hasMore && displayedConsultations.length > ITEMS_PER_PAGE && <div className="no-more-items">No more consultations</div>}
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Informed Consent Modal */}
        {showConsentModal && (
          <div className="modal-overlay" onClick={handleConsentReject}>
            <div className="modal-container consent-modal" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h3>Informed Consent for Tele-Counseling</h3>
                <button className="modal-close" onClick={handleConsentReject} aria-label="Close modal">
                  ✕
                </button>
              </div>

              <div className="modal-content">
                <div className="consent-content">
                  <div className="consent-icon">📋</div>

                  <div className="consent-text">
                    <p>By proceeding with this booking, I acknowledge and agree to the following:</p>

                    <ul className="consent-list">
                      <li>I am <strong>willing to undergo tele-counseling</strong> services through this platform.</li>
                      <li>I understand that I will be <strong>disclosing my concerns or problems</strong> with my guidance counselor.</li>
                      <li>I consent to participate in online counseling sessions and understand the nature of virtual mental health services.</li>
                      <li>I understand that all information shared will be kept confidential in accordance with professional guidelines.</li>
                    </ul>

                    <p className="consent-note">Please click "I Accept" if you agree to proceed with booking your counseling session.</p>
                  </div>
                </div>

                <div className="consent-actions">
                  <button className="btn-consent reject" onClick={handleConsentReject}>
                    I Decline
                  </button>
                  <button className="btn-consent accept" onClick={handleConsentAccept}>
                    I Accept
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        <AIAssistantFloating />
      </div>
    </div>
  );
}
