// FILE: src/components/ResponsiveHeader.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";
import logomark from "../assets/hinahon2.png";

export default function ResponsiveHeader({ 
  session, 
  title = "A Mental Health Booking Solution",
  showNavigation = true,
  showBackButton = false,
  backPath = "/landing"
}) {
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [profileImage, setProfileImage] = useState(null);

  useEffect(() => {
    if (session?.user?.user_metadata?.avatar_url) {
      setProfileImage(session.user.user_metadata.avatar_url);
    }
  }, [session]);

  // Prevent body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }

    return () => {
      document.body.style.overflow = "auto";
    };
  }, [isMobileMenuOpen]);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
    setIsMobileMenuOpen(false);
  };

  const handleNavigate = (path) => {
    navigate(path);
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <header className="landing-header">
        {/* Left Side - Logo and Title */}
        <div className="header-left" style={{
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "flex-start",
          gap: "10px",
        }}>
          <a href="LandingPage.jsx">
          <img
            src={logomark}
            alt="Hinahon Logo"
            style={{
              height: "45px",
              width: "45px",
              objectFit: "contain",
              display: "inline-block",
              verticalAlign: "middle",
            }}
          />
          </a>
          <div style={{ lineHeight: "1.2" }}>
            <div style={{
              fontWeight: "700",
              fontSize: "22px",
              color: "#e91e63",
              margin: 0,
              padding: 0,
            }}>
              Hinahon
            </div>
            <div style={{
              fontSize: "13px",
              color: "#666",
              margin: 0,
              padding: 0,
            }}>
              {title}
            </div>
          </div>
        </div>

        {/* Desktop Navigation */}
        <div className="header-right desktop-nav" style={{
          display: "flex",
          alignItems: "center",
          gap: "12px"
        }}>
          {showBackButton && (
            <button
              onClick={() => navigate(backPath)}
              style={{
                background: "none",
                border: "none",
                color: "#666",
                cursor: "pointer",
                font: "inherit",
                fontSize: "15px",
                fontWeight: "500",
                padding: "8px 12px",
                borderRadius: "6px",
                transition: "all 0.2s",
                display: "flex",
                alignItems: "center",
                gap: "6px"
              }}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = "#f5f5f5";
                e.target.style.color = "var(--pink)";
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = "transparent";
                e.target.style.color = "#666";
              }}
            >
              <svg 
                width="16" 
                height="16" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2"
              >
                <path d="M19 12H5M12 19l-7-7 7-7"/>
              </svg>
              Back
            </button>
          )}

          {showNavigation && !showBackButton && (
            <nav style={{ display: "flex", gap: 16, alignItems: "center" }}>
              <button
                onClick={() => navigate("/about")}
                style={{
                  background: "none",
                  border: "none",
                  color: "#666",
                  cursor: "pointer",
                  font: "inherit",
                  fontSize: "15px",
                  fontWeight: "500",
                  padding: "8px 12px",
                  borderRadius: "6px",
                  transition: "all 0.2s"
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = "#f5f5f5";
                  e.target.style.color = "var(--pink)";
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = "transparent";
                  e.target.style.color = "#666";
                }}
              >
                About
              </button>
              <button
                onClick={() => navigate("/articles")}
                style={{
                  background: "none",
                  border: "none",
                  color: "#666",
                  cursor: "pointer",
                  font: "inherit",
                  fontSize: "15px",
                  fontWeight: "500",
                  padding: "8px 12px",
                  borderRadius: "6px",
                  transition: "all 0.2s"
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = "#f5f5f5";
                  e.target.style.color = "var(--teal)";
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = "transparent";
                  e.target.style.color = "#666";
                }}
              >
                Articles
              </button>
            </nav>
          )}

          {/* Desktop Profile Dropdown */}
          {session && !session.isGuest && (
            <div style={{ position: "relative" }}>
              <DesktopProfileDropdown 
                session={session} 
                profileImage={profileImage}
                onSignOut={handleSignOut}
                onNavigate={handleNavigate}
              />
            </div>
          )}
        </div>

        {/* Mobile Hamburger Menu or Back Button */}
        <div className="mobile-nav">
          {showBackButton ? (
            <button
              onClick={() => navigate(backPath)}
              style={{
                background: "none",
                border: "none",
                padding: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "var(--pink)",
                transition: "all 0.2s"
              }}
              aria-label="Back"
              onMouseEnter={(e) => {
                e.target.style.transform = "scale(1.1)";
              }}
              onMouseLeave={(e) => {
                e.target.style.transform = "scale(1)";
              }}
            >
              <svg 
                width="28" 
                height="28" 
                viewBox="0 0 24 24" 
                fill="currentColor"
                stroke="none"
              >
                <path d="M11.47 3.84a.75.75 0 011.06 0l8.69 8.69a.75.75 0 101.06-1.06l-8.689-8.69a2.25 2.25 0 00-3.182 0l-8.69 8.69a.75.75 0 001.061 1.06l8.69-8.69z"/>
                <path d="M12 5.432l8.159 8.159c.03.03.06.058.091.086v6.198c0 1.035-.84 1.875-1.875 1.875H15a.75.75 0 01-.75-.75v-4.5a.75.75 0 00-.75-.75h-3a.75.75 0 00-.75.75V21a.75.75 0 01-.75.75H5.625a1.875 1.875 0 01-1.875-1.875v-6.198a2.29 2.29 0 00.091-.086L12 5.43z"/>
              </svg>
            </button>
          ) : (
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              style={{
                background: "none",
                border: "none",
                padding: "8px",
                cursor: "pointer",
                display: "flex",
                flexDirection: "column",
                gap: "5px",
                zIndex: 1001
              }}
              aria-label="Menu"
            >
              <span style={{
                width: "24px",
                height: "2px",
                backgroundColor: "var(--pink)",
                transition: "all 0.3s",
                transform: isMobileMenuOpen ? "rotate(45deg) translateY(7px)" : "none"
              }} />
              <span style={{
                width: "24px",
                height: "2px",
                backgroundColor: "var(--pink)",
                transition: "all 0.3s",
                opacity: isMobileMenuOpen ? 0 : 1
              }} />
              <span style={{
                width: "24px",
                height: "2px",
                backgroundColor: "var(--pink)",
                transition: "all 0.3s",
                transform: isMobileMenuOpen ? "rotate(-45deg) translateY(-7px)" : "none"
              }} />
            </button>
          )}
        </div>
      </header>

      {/* Mobile Sidebar Menu */}
      {isMobileMenuOpen && (
        <>
          {/* Overlay */}
          <div
            onClick={() => setIsMobileMenuOpen(false)}
            style={{
              position: "fixed",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: "rgba(0, 0, 0, 0.5)",
              zIndex: 9999,
              animation: "fadeIn 0.3s ease-out"
            }}
          />

          {/* Sidebar */}
          <div style={{
            position: "fixed",
            top: 0,
            right: 0,
            width: "280px",
            maxWidth: "85vw",
            height: "100vh",
            height: "100dvh",
            backgroundColor: "white",
            zIndex: 10000,
            boxShadow: "-4px 0 20px rgba(0, 0, 0, 0.15)",
            display: "flex",
            flexDirection: "column",
            animation: "slideInRight 0.3s ease-out",
            overflowX: "hidden"
          }}>
            {/* Sidebar Header - Match main header padding */}
            <div style={{
              padding: "14px 20px",
              borderBottom: "1px solid #f0f0f0",
              background: "linear-gradient(135deg, rgba(233, 30, 99, 0.05), rgba(0, 191, 165, 0.05))",
              flexShrink: 0
            }}>
              <div style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                height: "45px"
              }}>
                <h3 style={{
                  margin: 0,
                  color: "var(--pink)",
                  fontSize: "18px",
                  fontWeight: "700",
                  lineHeight: "45px"
                }}>
                  Menu
                </h3>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  style={{
                    background: "none",
                    border: "none",
                    fontSize: "24px",
                    color: "#999",
                    cursor: "pointer",
                    padding: "8px",
                    lineHeight: 1,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    width: "40px",
                    height: "40px"
                  }}
                  aria-label="Close menu"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Navigation Links - Scrollable area */}
            <div style={{
              flex: 1,
              padding: "12px 0",
              overflowY: "auto",
              overflowX: "hidden",
              WebkitOverflowScrolling: "touch"
            }}>
              {showBackButton && (
                <button
                  onClick={() => handleNavigate(backPath)}
                  style={{
                    width: "100%",
                    padding: "14px 20px",
                    border: "none",
                    background: "white",
                    textAlign: "left",
                    cursor: "pointer",
                    fontSize: "15px",
                    color: "#666",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    gap: "12px",
                    transition: "background 0.2s"
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.backgroundColor = "#f8f9fa";
                    e.target.style.color = "var(--pink)";
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.backgroundColor = "white";
                    e.target.style.color = "#666";
                  }}
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M19 12H5M12 19l-7-7 7-7"/>
                  </svg>
                  Back
                </button>
              )}

              {showNavigation && !showBackButton && (
                <>
                  <button
                    onClick={() => handleNavigate("/about")}
                    style={{
                      width: "100%",
                      padding: "14px 20px",
                      border: "none",
                      background: "white",
                      textAlign: "left",
                      cursor: "pointer",
                      fontSize: "15px",
                      color: "var(--text)",
                      fontWeight: "500",
                      display: "flex",
                      alignItems: "center",
                      gap: "12px",
                      transition: "background 0.2s"
                    }}
                    onMouseEnter={(e) => e.target.style.backgroundColor = "#f8f9fa"}
                    onMouseLeave={(e) => e.target.style.backgroundColor = "white"}
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <circle cx="12" cy="12" r="10"/>
                      <line x1="12" y1="16" x2="12" y2="12"/>
                      <line x1="12" y1="8" x2="12.01" y2="8"/>
                    </svg>
                    About
                  </button>

                  <button
                    onClick={() => handleNavigate("/articles")}
                    style={{
                      width: "100%",
                      padding: "14px 20px",
                      border: "none",
                      background: "white",
                      textAlign: "left",
                      cursor: "pointer",
                      fontSize: "15px",
                      color: "var(--text)",
                      fontWeight: "500",
                      display: "flex",
                      alignItems: "center",
                      gap: "12px",
                      transition: "background 0.2s"
                    }}
                    onMouseEnter={(e) => e.target.style.backgroundColor = "#f8f9fa"}
                    onMouseLeave={(e) => e.target.style.backgroundColor = "white"}
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
                    </svg>
                    Articles
                  </button>
                </>
              )}
            </div>

            {/* Profile Section at Bottom - Fixed position */}
            {session && !session.isGuest && (
              <div style={{
                borderTop: "1px solid #f0f0f0",
                padding: "12px 16px",
                background: "#fafafa",
                flexShrink: 0
              }}>
                <div style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  marginBottom: "10px"
                }}>
                  <div style={{
                    width: "42px",
                    height: "42px",
                    borderRadius: "50%",
                    background: profileImage 
                      ? "transparent" 
                      : "linear-gradient(135deg, var(--pink), var(--teal))",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "white",
                    fontSize: "18px",
                    fontWeight: "600",
                    border: "2px solid white",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
                    overflow: "hidden",
                    flexShrink: 0
                  }}>
                    {profileImage ? (
                      <img 
                        src={profileImage} 
                        alt="Profile"
                        style={{
                          width: "100%",
                          height: "100%",
                          objectFit: "cover"
                        }}
                      />
                    ) : (
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                        <circle cx="12" cy="7" r="4"/>
                      </svg>
                    )}
                  </div>
                  <div style={{ flex: 1, overflow: "hidden", minWidth: 0 }}>
                    <div style={{
                      fontSize: "13px",
                      fontWeight: "600",
                      color: "var(--text)",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap"
                    }}>
                      {session.user?.user_metadata?.name || session.user?.email?.split('@')[0] || "User"}
                    </div>
                    <div style={{
                      fontSize: "11px",
                      color: "#999",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap"
                    }}>
                      {session.user?.email}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleNavigate("/profile")}
                  style={{
                    width: "100%",
                    padding: "9px 12px",
                    border: "1px solid #e0e0e0",
                    background: "white",
                    borderRadius: "8px",
                    cursor: "pointer",
                    fontSize: "13px",
                    color: "var(--text)",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                    marginBottom: "8px",
                    transition: "all 0.2s"
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.backgroundColor = "#f8f9fa";
                    e.target.style.borderColor = "var(--teal)";
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.backgroundColor = "white";
                    e.target.style.borderColor = "#e0e0e0";
                  }}
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                  </svg>
                  Account Profile
                </button>

                <button
                  onClick={handleSignOut}
                  style={{
                    width: "100%",
                    padding: "9px 12px",
                    border: "1px solid #ffcdd2",
                    background: "white",
                    borderRadius: "8px",
                    cursor: "pointer",
                    fontSize: "13px",
                    color: "var(--pink)",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                    transition: "all 0.2s"
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.backgroundColor = "#fff5f8";
                    e.target.style.borderColor = "var(--pink)";
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.backgroundColor = "white";
                    e.target.style.borderColor = "#ffcdd2";
                  }}
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                    <polyline points="16 17 21 12 16 7"/>
                    <line x1="21" y1="12" x2="9" y2="12"/>
                  </svg>
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </>
      )}

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        @keyframes slideInRight {
          from {
            transform: translateX(100%);
          }
          to {
            transform: translateX(0);
          }
        }

        .desktop-nav {
          display: flex !important;
        }

        .mobile-nav {
          display: none !important;
        }

        @media (max-width: 768px) {
          .desktop-nav {
            display: none !important;
          }

          .mobile-nav {
            display: block !important;
          }

          .landing-header {
            flex-direction: row !important;
            align-items: center !important;
            justify-content: space-between !important;
            padding: 14px 20px !important;
          }

          .header-left {
            flex-direction: row !important;
            align-items: center !important;
            justify-content: flex-start !important;
            text-align: left !important;
          }

          .header-left > div {
            text-align: left !important;
          }
        }

        @media (max-width: 520px) {
          .landing-header {
            padding: 12px 16px !important;
          }
          
          .header-left img {
            height: 40px !important;
            width: 40px !important;
          }
          
          .header-left > div > div:first-child {
            font-size: 18px !important;
          }
          
          .header-left > div > div:last-child {
            font-size: 11px !important;
          }
        }
      `}</style>
    </>
  );
}

function DesktopProfileDropdown({ session, profileImage, onSignOut, onNavigate }) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = React.useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen]);

  return (
    <div ref={dropdownRef} style={{ position: "relative" }}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        style={{
          width: "40px",
          height: "40px",
          borderRadius: "50%",
          border: "2px solid var(--teal)",
          background: profileImage 
            ? "transparent" 
            : "linear-gradient(135deg, var(--pink), var(--teal))",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "white",
          fontSize: "16px",
          fontWeight: "600",
          transition: "all 0.2s",
          overflow: "hidden",
          padding: 0,
          position: "relative"
        }}
        onMouseEnter={(e) => {
          e.target.style.transform = "scale(1.05)";
          e.target.style.boxShadow = "0 4px 12px rgba(0,191,165,0.3)";
        }}
        onMouseLeave={(e) => {
          e.target.style.transform = "scale(1)";
          e.target.style.boxShadow = "none";
        }}
      >
        {profileImage ? (
          <img 
            src={profileImage} 
            alt="Profile"
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              borderRadius: "50%"
            }}
          />
        ) : (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
        )}
      </button>

      {isOpen && (
        <div style={{
          position: "absolute",
          top: "calc(100% + 8px)",
          right: 0,
          backgroundColor: "white",
          borderRadius: "12px",
          boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
          border: "1px solid #e0e0e0",
          minWidth: "200px",
          zIndex: 1000,
          overflow: "hidden",
          animation: "dropdownFade 0.2s ease-out"
        }}>
          <div style={{
            padding: "16px",
            borderBottom: "1px solid #f0f0f0",
            backgroundColor: "#f8f9fa"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
              <div style={{
                width: "32px",
                height: "32px",
                borderRadius: "50%",
                background: profileImage 
                  ? "transparent" 
                  : "linear-gradient(135deg, var(--pink), var(--teal))",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
                fontSize: "14px",
                fontWeight: "600",
                overflow: "hidden",
                flexShrink: 0
              }}>
                {profileImage ? (
                  <img 
                    src={profileImage} 
                    alt="Profile"
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "cover"
                    }}
                  />
                ) : (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                  </svg>
                )}
              </div>
              <div style={{ flex: 1, overflow: "hidden" }}>
                <div style={{
                  fontSize: "14px",
                  fontWeight: "600",
                  color: "var(--text)",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap"
                }}>
                  {session?.user?.user_metadata?.name || session?.user?.email?.split('@')[0] || "User"}
                </div>
                <div style={{
                  fontSize: "12px",
                  color: "#999",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap"
                }}>
                  {session?.user?.email}
                </div>
              </div>
            </div>
          </div>

          <div style={{ padding: "8px 0" }}>
            <button
              onClick={() => {
                setIsOpen(false);
                onNavigate("/profile");
              }}
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "none",
                background: "white",
                textAlign: "left",
                cursor: "pointer",
                fontSize: "14px",
                color: "var(--text)",
                fontWeight: "500",
                display: "flex",
                alignItems: "center",
                gap: "12px",
                transition: "background 0.2s"
              }}
              onMouseEnter={(e) => e.target.style.backgroundColor = "#f8f9fa"}
              onMouseLeave={(e) => e.target.style.backgroundColor = "white"}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                <circle cx="12" cy="7" r="4"/>
              </svg>
              Account Profile
            </button>

            <div style={{ height: "1px", backgroundColor: "#f0f0f0", margin: "4px 0" }} />

            <button
              onClick={() => {
                setIsOpen(false);
                onSignOut();
              }}
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "none",
                background: "white",
                textAlign: "left",
                cursor: "pointer",
                fontSize: "14px",
                color: "var(--pink)",
                fontWeight: "500",
                display: "flex",
                alignItems: "center",
                gap: "12px",
                transition: "background 0.2s"
              }}
              onMouseEnter={(e) => e.target.style.backgroundColor = "#fff5f8"}
              onMouseLeave={(e) => e.target.style.backgroundColor = "white"}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                <polyline points="16 17 21 12 16 7"/>
                <line x1="21" y1="12" x2="9" y2="12"/>
              </svg>
              Sign Out
            </button>
          </div>
        </div>
      )}

      <style>{`
        @keyframes dropdownFade {
          from {
            opacity: 0;
            transform: translateY(-8px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}