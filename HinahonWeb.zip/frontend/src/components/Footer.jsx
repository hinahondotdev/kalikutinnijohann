import React, { useState } from 'react';
import '../styles.css';
import logomark from "../assets/hinahon2.png";
import { TermsAndConditions, PrivacyPolicy} from './LegalContent';

const Footer = () => {
  const [showTerms, setShowTerms] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showContact, setShowContact] = useState(false);

  const Modal = ({ isOpen, onClose, title, children }) => {
    if (!isOpen) return null;

    return (
      <div 
        className="footer-modal-overlay" 
        onClick={onClose}
      >
        <div 
          className="footer-modal-container" 
          onClick={(e) => e.stopPropagation()}
        >
          <div className="footer-modal-header">
            <h2>{title}</h2>
            <button
              className="footer-modal-close"
              onClick={onClose}
              aria-label="Close modal"
            >
              ×
            </button>
          </div>
          <div className="footer-modal-content">
            {children}
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <footer className="app-footer-new">
        <div className="footer-container-new">
          {/* Top Section: Quote */}
          <div className="footer-quote">
            "In Hinahon, your Mental Wellness is our priority."
          </div>

          {/* Middle Section: Icons and Links */}
          <div className="footer-middle">
            {/* Social Icons */}
            <div className="footer-social-icons">
              <a
                href="https://www.facebook.com/LPUCATC"
                target="_blank"
                rel="noopener noreferrer"
                className="footer-icon-circle"
                aria-label="Facebook"
              >
                <svg width="28" height="28" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </a>

              <a
                href="mailto:support@hinahon.ph"
                className="footer-icon-circle"
                aria-label="Email"
              >
                <svg width="28" height="28" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                </svg>
              </a>

              <a
                href="https://lpubatangas.edu.ph/counseling-and-testing-center/"
                target="_blank"
                rel="noopener noreferrer"
                className="footer-icon-circle"
                aria-label="Website"
              >
                <svg width="28" height="28" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                </svg>
              </a>
            </div>

            {/* Divider */}
            <div className="footer-divider"></div>

            {/* Links Section */}
            <div className="footer-links-section">
              <button
                onClick={() => setShowTerms(true)}
                className="footer-link-text"
              >
                Terms and Conditions
              </button>
              <button
                onClick={() => setShowPrivacy(true)}
                className="footer-link-text"
              >
                Privacy Policy
              </button>
            </div>

            {/* Divider */}
            <div className="footer-divider"></div>

            {/* Crisis Hotline */}
            <div className="footer-crisis-section">
              <div className="footer-crisis-title">CRISIS HOTLINE</div>
              <div className="footer-crisis-subtitle">Help is Available. You are not alone.</div>
              <a href="tel:09195871553" className="footer-crisis-number">0919-587-1553</a>
            </div>
          </div>

          {/* Bottom Section: Copyright */}
          <div className="footer-bottom">
            <div className="footer-separator"></div>
            <p className="footer-copyright">@2025 TEAM HINAHON | All Rights Reserved.</p>
          </div>
        </div>
      </footer>

      {/* Terms & Conditions Modal */}
      <Modal
        isOpen={showTerms}
        onClose={() => setShowTerms(false)}
        title="Terms & Conditions"
      >
        <TermsAndConditions />
      </Modal>

      {/* Privacy Policy Modal */}
      <Modal
        isOpen={showPrivacy}
        onClose={() => setShowPrivacy(false)}
        title="Privacy Policy"
      >
        <PrivacyPolicy />
      </Modal>
    </>
  );
};

export default Footer;