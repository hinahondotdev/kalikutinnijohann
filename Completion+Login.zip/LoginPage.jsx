import React, { useState, useEffect, useRef, useLayoutEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";
import {
  validatePasswordWithFeedback,
  isCommonPassword,
  getPasswordStrengthInfo,
  getPasswordChecklist
} from "../utils/passwordUtils";
import "../styles.css";
import "../styles2.css";
import logo from "../assets/hinahon.png";
import logo1 from "../assets/lpub.png";
import logo2 from "../assets/catc.png";
import bgImage from "../assets/bg-login.png";
import bgImage2 from "../assets/bg-login2.webp";
import bgImage3 from "../assets/bg-login3.webp";
import bgImage4 from "../assets/bg-login4.jpg";
import logomark from "../assets/hinahon2.png";
import { TermsAndConditions, PrivacyPolicy, ContactInfo } from '../components/LegalContent';

export default function LoginPage({ setSession }) {
  const navigate = useNavigate();
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const [resetLoading, setResetLoading] = useState(false);
  const [resetMessage, setResetMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [acceptedPrivacy, setAcceptedPrivacy] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: ""
  });

  // Use the four background assets for the animated crossfade backgrounds
  const backgrounds = [bgImage, bgImage2, bgImage3, bgImage4];

  // Background transition settings
  const INTERVAL_MS = 10000;
  const TRANSITION_MS = 1000;

  // Layer state for crossfade
  const [layerAIndex, setLayerAIndex] = useState(() => Math.floor(Math.random() * backgrounds.length));
  const [layerBIndex, setLayerBIndex] = useState(null);
  const [activeLayer, setActiveLayer] = useState("A"); // "A" or "B"

  const activeIndexRef = useRef(layerAIndex);
  useEffect(() => {
    activeIndexRef.current = activeLayer === "A" ? layerAIndex : layerBIndex;
  }, [layerAIndex, layerBIndex, activeLayer]);

  const preload = (src) => {
    return new Promise((res) => {
      const img = new Image();
      img.onload = () => res(true);
      img.onerror = () => res(false);
      img.src = src;
    });
  };

  useEffect(() => {
    let mounted = true;
    const id = setInterval(async () => {
      if (!mounted || backgrounds.length < 2) return;

      let current = activeIndexRef.current;
      if (current === null || current === undefined) current = layerAIndex;

      let next = Math.floor(Math.random() * backgrounds.length);
      while (next === current) {
        next = Math.floor(Math.random() * backgrounds.length);
      }

      await preload(backgrounds[next]);

      if (!mounted) return;
      if (activeLayer === "A") {
        setLayerBIndex(next);
        requestAnimationFrame(() => {
          setActiveLayer("B");
        });
        setTimeout(() => {
          if (!mounted) return;
        }, TRANSITION_MS + 50);
      } else {
        setLayerAIndex(next);
        requestAnimationFrame(() => {
          setActiveLayer("A");
        });
        setTimeout(() => {
          if (!mounted) return;
        }, TRANSITION_MS + 50);
      }
    }, INTERVAL_MS);

    return () => {
      mounted = false;
      clearInterval(id);
    };
  }, [backgrounds.length, activeLayer, layerAIndex, layerBIndex]);

  useEffect(() => {
    let mounted = true;

    const checkInitialSession = async () => {
      const { data } = await supabase.auth.getSession();
      if (!mounted) return;

      if (data?.session?.user && !data.session.user.email_confirmed_at) {
        console.log("🔄 Clearing password recovery session");
        await supabase.auth.signOut();
      }
    };

    checkInitialSession();

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    let checkTimeout;

    const resetLoadingIfCancelled = async () => {
      if (!loading) return;

      console.log("🔍 Checking if OAuth was completed or cancelled...");

      await new Promise(resolve => setTimeout(resolve, 1500));

      try {
        const { data: { session } } = await supabase.auth.getSession();

        if (!session) {
          console.log("🔙 OAuth cancelled - no session found, resetting loading state");
          setLoading(false);
        } else {
          console.log("✅ OAuth completed successfully");
        }
      } catch (err) {
        console.error("Error checking session:", err);
        setLoading(false);
      }
    };

    const handleFocus = () => {
      if (loading) {
        console.log("🪟 Window focused while loading");
        checkTimeout = setTimeout(resetLoadingIfCancelled, 500);
      }
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && loading) {
        console.log("👁️ Page visible while loading");
        checkTimeout = setTimeout(resetLoadingIfCancelled, 500);
      }
    };

    window.addEventListener('focus', handleFocus);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (checkTimeout) clearTimeout(checkTimeout);
    };
  }, [loading]);

  // --- NEW: make whole page non-scrollable while this component is mounted ---
  useEffect(() => {
    // Save previous inline styles so we can restore them on cleanup.
    const prevBodyOverflow = document.body.style.overflow;
    const prevBodyPosition = document.body.style.position;
    const prevBodyTop = document.body.style.top;
    const prevBodyLeft = document.body.style.left;
    const prevBodyRight = document.body.style.right;
    const prevBodyWidth = document.body.style.width;
    const prevBodyPaddingRight = document.body.style.paddingRight;
    const prevHtmlOverflow = document.documentElement.style.overflow;
    const prevHtmlOverscroll = document.documentElement.style.overscrollBehavior;

    // Prevent page layout jump by adding same padding-right as scrollbar width
    const scrollbarWidth = Math.max(0, window.innerWidth - document.documentElement.clientWidth);
    if (scrollbarWidth > 0) {
      document.body.style.paddingRight = `${scrollbarWidth}px`;
    }

    // Preserve scroll position and lock the page
    const scrollY = window.scrollY || window.pageYOffset || 0;
    // Fix body so it can't scroll and keep the current viewport
    document.body.style.position = "fixed";
    document.body.style.top = `-${scrollY}px`;
    document.body.style.left = "0";
    document.body.style.right = "0";
    document.body.style.width = "100%";
    document.body.style.overflow = "hidden";

    // Also ensure html does not allow overscroll (mobile bounce) and hide overflow
    document.documentElement.style.overflow = "hidden";
    document.documentElement.style.overscrollBehavior = "none";

    return () => {
      // restore previous styles
      document.documentElement.style.overflow = prevHtmlOverflow;
      document.documentElement.style.overscrollBehavior = prevHtmlOverscroll;
      document.body.style.overflow = prevBodyOverflow;
      document.body.style.position = prevBodyPosition;
      document.body.style.top = prevBodyTop;
      document.body.style.left = prevBodyLeft;
      document.body.style.right = prevBodyRight;
      document.body.style.width = prevBodyWidth;
      document.body.style.paddingRight = prevBodyPaddingRight;

      // restore scroll position
      // parse the preserved top if present
      const restoredScrollY = Math.abs(parseInt(document.body.style.top || "") || scrollY);
      window.scrollTo(0, restoredScrollY);
    };
  }, []);
  // --- END non-scrollable effect ---

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setError("");
  };

  async function signInWithGoogle() {
    try {
      setLoading(true);
      setError("");

      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: window.location.origin,
          queryParams: {
            access_type: 'offline'
          }
        }
      });

      if (error) throw error;
    } catch (err) {
      console.error("Google sign in error:", err);
      setError(err.message || "Failed to sign in with Google");
      setLoading(false);
    }
  }

  async function handleEmailAuth(e) {
    e.preventDefault();
    setError("");

    if (!formData.email || !formData.password) {
      setError("Please fill in all fields");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError("Please enter a valid email address");
      return;
    }

    const tempEmailDomains = [
      'tempmail.com', 'guerrillamail.com', '10minutemail.com',
      'mailinator.com', 'throwaway.email', 'temp-mail.org',
      'fakeinbox.com', 'trashmail.com', 'maildrop.cc'
    ];
    const emailDomain = formData.email.split('@')[1]?.toLowerCase();
    if (tempEmailDomains.includes(emailDomain)) {
      setError("Temporary email addresses are not allowed. Please use a valid email.");
      return;
    }

    if (isSignUp) {
      if (!acceptedTerms) {
        setError("You must accept the Terms & Conditions to create an account");
        return;
      }

      if (!acceptedPrivacy) {
        setError("You must accept the Privacy Policy to create an account");
        return;
      }

      if (formData.password.length < 8) {
        setError("Password must be at least 8 characters long");
        return;
      }

      const validation = validatePasswordWithFeedback(formData.password);
      if (!validation.isValid) {
        setError(`Password must contain: ${validation.failedRequirements.join(", ")}`);
        return;
      }

      if (isCommonPassword(formData.password)) {
        setError("This password is too common and easily guessable. Please choose a more unique password.");
        return;
      }

      if (formData.password !== formData.confirmPassword) {
        setError("Passwords do not match");
        return;
      }
    } else {
      if (formData.password.length < 6) {
        setError("Password must be at least 6 characters");
        return;
      }
    }

    setLoading(true);

    try {
      if (isSignUp) {
        const { data, error } = await supabase.auth.signUp({
          email: formData.email,
          password: formData.password,
          options: {
            emailRedirectTo: `${window.location.origin}/auth/callback`,
            data: {
              email: formData.email
            }
          }
        });

        if (error) throw error;

        if (data?.user) {
          if (data.user.identities && data.user.identities.length === 0) {
            setError("This email is already registered. Please sign in instead.");
            setIsSignUp(false);
            setLoading(false);
            return;
          }

          alert(
            "✅ Account created successfully!\n\n" +
            "📧 We've sent a verification email to:\n" +
            formData.email + "\n\n" +
            "Please check your inbox and click the verification link to activate your account.\n\n" +
            "⚠️ Check your spam folder if you don't see it within a few minutes."
          );

          setIsSignUp(false);
          setFormData({ email: "", password: "", confirmPassword: "" });
          setAcceptedTerms(false);
          setAcceptedPrivacy(false);
          setLoading(false);
        }
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: formData.email,
          password: formData.password
        });

        if (error) throw error;

        if (data?.user && !data.user.email_confirmed_at) {
          setError(
            "Email not verified. Please check your inbox for the verification email.\n\n" +
            "Need a new verification link? Contact support."
          );
          setLoading(false);
          return;
        }

        if (data?.session) {
          setSession(data.session);
        }
      }
    } catch (err) {
      console.error("Auth error:", err);

      if (err.message.includes("Invalid login credentials")) {
        setError("Invalid email or password. Please check your credentials and try again.");
      } else if (err.message.includes("Email not confirmed")) {
        setError("Please verify your email address before signing in. Check your inbox for the verification link.");
      } else if (err.message.includes("Email rate limit exceeded")) {
        setError("Too many requests. Please wait a few minutes before trying again.");
      } else {
        setError(err.message || "Authentication failed. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  }

  async function handlePasswordReset(e) {
    e.preventDefault();
    setResetMessage("");

    if (!resetEmail) {
      setResetMessage("Please enter your email address");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(resetEmail)) {
      setResetMessage("Please enter a valid email address");
      return;
    }

    setResetLoading(true);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(resetEmail, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) throw error;

      setResetMessage(
        "✅ Password reset email sent!\n\n" +
        "Please check your inbox and click the link to reset your password.\n\n" +
        "⚠️ Check your spam folder if you don't see it within a few minutes."
      );

      setTimeout(() => {
        setResetEmail("");
        setShowForgotPassword(false);
        setResetMessage("");
      }, 5000);

    } catch (err) {
      console.error("Password reset error:", err);
      setResetMessage(err.message || "Failed to send reset email. Please try again.");
    } finally {
      setResetLoading(false);
    }
  }

  const toggleAuthMode = () => {
    setIsSignUp(!isSignUp);
    setError("");
    setFormData({ email: "", password: "", confirmPassword: "" });
    setShowPassword(false);
    setAcceptedTerms(false);
    setAcceptedPrivacy(false);
  };

  const passwordStrength = isSignUp && formData.password
    ? getPasswordStrengthInfo(formData.password)
    : null;

  const passwordChecklist = isSignUp && formData.password
    ? getPasswordChecklist(formData.password)
    : null;

  const Modal = ({ isOpen, onClose, title, children }) => {
    if (!isOpen) return null;

    return (
      <div
        className="footer-modal-overlay"
        onClick={onClose}
        style={{
          position: "fixed",
          inset: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 2000,
          backgroundColor: "rgba(0,0,0,0.5)",
          // ensure overlay itself never scrolls (prevents outer scrollbar)
          overflow: "hidden"
        }}
      >
        <div
          className="footer-modal-container"
          onClick={(e) => e.stopPropagation()}
          style={{
            background: "white",
            borderRadius: 12,
            maxWidth: 820,
            width: "92%",
            maxHeight: "calc(100dvh - 40px)",
            boxSizing: "border-box",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
            WebkitOverflowScrolling: "touch",
            boxShadow: "0 8px 30px rgba(0,0,0,0.2)",
          }}
        >
          <div className="footer-modal-header" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: 20 }}>
            <h2 style={{ margin: 0 }}>{title}</h2>
            <button
              className="footer-modal-close"
              onClick={onClose}
              aria-label="Close modal"
              style={{ fontSize: 22, background: "none", border: "none", cursor: "pointer" }}
            >
              ×
            </button>
          </div>
          <div className="footer-modal-content" style={{ marginTop: 0, padding: 20, overflowY: "auto", flex: 1 }}>
            {children}
          </div>
        </div>
      </div>
    );
  };

  // Refs + state used to measure and animate container size changes
  const panelRef = useRef(null);
  const panelInnerRef = useRef(null);
  const [panelHeight, setPanelHeight] = useState("auto");

  // measure function: set explicit pixel height on outer panel to enable smooth transition
  const measurePanel = () => {
    const inner = panelInnerRef.current;
    if (!inner) return;
    // use offsetHeight to account for rendered height
    const h = inner.offsetHeight;
    // add a small buffer to avoid 1px jumps from subpixel rounding
    setPanelHeight(`${h + 2}px`);
  };

  // measure on mount, on toggles that change layout, and on window resize
  useLayoutEffect(() => {
    // measure after DOM paint
    requestAnimationFrame(measurePanel);
  });

  useEffect(() => {
    // measure after toggling isSignUp or when formData changes (password checklist toggles)
    // small timeout to allow DOM updates (e.g. password checklist rendering) before measure
    const id = setTimeout(measurePanel, 40);
    return () => clearTimeout(id);
    // include formData.password because password checklist can change height
  }, [isSignUp, formData.password, passwordChecklist, showForgotPassword, showTermsModal, showPrivacyModal]);

  useEffect(() => {
    const onResize = () => {
      // measure slightly deferred so layout stabilizes
      requestAnimationFrame(measurePanel);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // Inline styles/classes for the background layers. Keeping CSS here so it's self-contained.
  const bgLayerBaseStyle = {
    position: "absolute",
    inset: 0,
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    transition: `opacity ${TRANSITION_MS}ms ease`,
    willChange: "opacity",
  };

  return (
    <div
      className="auth-page"
      style={{
        position: "relative",
        overflowX: "hidden",
        height: "100vh"
      }}
    >
      <div
        aria-hidden="true"
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 0,
          pointerEvents: "none"
        }}
      >
        {/* Layer A */}
        {layerAIndex !== null && (
          <div
            key={`layerA-${layerAIndex}`} 
            className="bg-layer"
            style={{
              ...bgLayerBaseStyle,
              backgroundImage: `url(${backgrounds[layerAIndex]})`,
              opacity: activeLayer === "A" ? 1 : 0,
              zIndex: activeLayer === "A" ? 2 : 1,
            }}
          />
        )}

        {/* Layer B */}
        {layerBIndex !== null && (
          <div
            key={`layerB-${layerBIndex}`} 
            className="bg-layer"
            style={{
              ...bgLayerBaseStyle,
              backgroundImage: `url(${backgrounds[layerBIndex]})`,
              opacity: activeLayer === "B" ? 1 : 0,
              zIndex: activeLayer === "B" ? 2 : 1,
            }}
          />
        )}
      </div>

      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          backgroundColor: "rgba(255, 255, 255, 0.3)",
          zIndex: 0,
        }}
      ></div>

      <div className="auth-container">
        <div
          className="auth-panel"
          role="region"
          aria-label="Authentication panel"
          ref={panelRef}
          style={{
            height: panelHeight === "auto" ? "auto" : panelHeight,
            marginTop: "0px"
          }}
        >
          <div className="auth-panel-inner" ref={panelInnerRef}>
            <div className="auth-hero" aria-hidden="false">
              <div className="nav-slim" style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "10px",
              }}>
                <img
                  src={logo1}
                  alt="Logo 1"
                  style={{ height: "48px", width: "auto" }}
                />
                <img
                  src={logo2}
                  alt="Logo 2"
                  style={{ height: "48px", width: "auto" }}
                />
              </div>

              <div className="hero-content fade-wrap enter">
                <img
                  src={logo}
                  alt="Hinahon Logo"
                  className="brand-big"
                  style={{ width: "95%", height: "auto", justifyContent: "center" }}
                />
                <p className="hero-sub1" style={{ marginTop: 6 }}>
                  The Digital Solution for Mental Wellness Counselling in LPU-Batangas.
                </p>
                <p className="hero-sub2" style={{ marginTop: 6 }}>
                  {isSignUp
                    ? "Join our community and start your journey to better mental health."
                    : "Welcome back! Sign in to continue your mental health journey."
                  }
                </p>
              </div>
            </div>

            <div className="auth-divider" aria-hidden="true" />

            <div className="auth-card" aria-label={isSignUp ? "Sign up form" : "Sign in form"}>
              <div className="card-header">
                <div className="logo-small" style={{ fontSize: "35px", fontFamily: "Playfair Display" }}>Step into Calm</div>
                <div className="small-tag" style={{ fontSize: "17px" }}>
                  {isSignUp ? "Create your account" : "Sign in to your account"}
                </div>
              </div>

              {error && (
                <div style={{
                  backgroundColor: "#ffebee",
                  color: "#c62828",
                  padding: "12px",
                  borderRadius: "8px",
                  fontSize: "13px",
                  marginBottom: "12px"
                }}>
                  {error}
                </div>
              )}

              <div className={`fade-wrap enter`} style={{ width: "100%" }}>
                <form onSubmit={handleEmailAuth} className="login-form">
                  <div className="field">
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="Email address"
                      disabled={loading}
                      required
                    />
                  </div>

                  <div className="field">
                    <div style={{ position: "relative" }}>
                      <input
                        type={showPassword ? "text" : "password"}
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        placeholder="Password"
                        disabled={loading}
                        required
                        style={{ paddingRight: "45px" }}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        disabled={loading}
                        style={{
                          position: "absolute",
                          right: "10px",
                          top: "50%",
                          transform: "translateY(-50%)",
                          background: "none",
                          border: "none",
                          cursor: loading ? "not-allowed" : "pointer",
                          padding: "8px",
                          color: "#666",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          width: "36px",
                          height: "36px",
                          borderRadius: "4px",
                          pointerEvents: "auto",
                          zIndex: 10
                        }}
                        aria-label={showPassword ? "Hide password" : "Show password"}
                      >
                        {showPassword ? (
                          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                          </svg>
                        ) : (
                          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                            <line x1="1" y1="1" x2="23" y2="23"></line>
                          </svg>
                        )}
                      </button>
                    </div>

                    {isSignUp && formData.password && passwordStrength && (
                      <div style={{ marginTop: '8px' }}>
                        <div style={{
                          height: '4px',
                          backgroundColor: '#e0e0e0',
                          borderRadius: '2px',
                          overflow: 'hidden',
                          marginBottom: '6px'
                        }}>
                          <div style={{
                            height: '100%',
                            width: `${passwordStrength.percentage}%`,
                            backgroundColor: passwordStrength.color,
                            transition: 'all 0.3s ease'
                          }}></div>
                        </div>
                        <div style={{
                          fontSize: '12px',
                          color: passwordStrength.color,
                          fontWeight: '600'
                        }}>
                          Password Strength: {passwordStrength.label}
                        </div>
                      </div>
                    )}
                  </div>

                  {isSignUp && formData.password && passwordChecklist && (
                    <div style={{
                      backgroundColor: '#f5f9ff',
                      padding: '12px',
                      borderRadius: '8px',
                      fontSize: '12px',
                      marginBottom: '12px',
                      border: '1px solid #e3f2fd'
                    }}>
                      <p style={{
                        margin: '0 0 10px 0',
                        fontWeight: '600',
                        color: '#1976d2',
                        fontSize: '13px'
                      }}>
                        🔐 Password Requirements:
                      </p>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                        {passwordChecklist.map(item => (
                          <div
                            key={item.id}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px',
                              color: item.met ? '#388e3c' : '#666'
                            }}
                          >
                            <span>{item.icon}</span>
                            <span>{item.label}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {isSignUp && (
                    <div className="field">
                      <div style={{ position: "relative" }}>
                        <input
                          type={showPassword ? "text" : "password"}
                          name="confirmPassword"
                          value={formData.confirmPassword}
                          onChange={handleChange}
                          placeholder="Confirm password"
                          disabled={loading}
                          required
                          style={{ paddingRight: "45px" }}
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          disabled={loading}
                          style={{
                            position: "absolute",
                            right: "10px",
                            top: "50%",
                            transform: "translateY(-50%)",
                            background: "none",
                            border: "none",
                            cursor: loading ? "not-allowed" : "pointer",
                            padding: "8px",
                            color: "#666",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            width: "36px",
                            height: "36px",
                            borderRadius: "4px",
                            pointerEvents: "auto",
                            zIndex: 10
                          }}
                          aria-label={showPassword ? "Hide password" : "Show password"}
                        >
                          {showPassword ? (
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                              <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                          ) : (
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                              <line x1="1" y1="1" x2="23" y2="23"></line>
                            </svg>
                          )}
                        </button>
                      </div>
                    </div>
                  )}

                  {isSignUp && (
                    <div style={{ marginBottom: '16px' }}>
                      <div style={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '10px',
                        marginBottom: '10px'
                      }}>
                        <input
                          type="checkbox"
                          id="terms-checkbox"
                          checked={acceptedTerms}
                          onChange={(e) => setAcceptedTerms(e.target.checked)}
                          disabled={loading}
                          style={{
                            marginTop: '3px',
                            minWidth: '16px',
                            width: '16px',
                            height: '16px',
                            cursor: loading ? 'not-allowed' : 'pointer',
                            flexShrink: 0
                          }}
                        />
                        <label
                          htmlFor="terms-checkbox"
                          style={{
                            fontSize: '13px',
                            color: '#666',
                            lineHeight: '1.5',
                            cursor: loading ? 'not-allowed' : 'pointer',
                            flex: 1,
                            userSelect: 'none',
                            display: 'block'
                          }}
                        >
                          I agree to the{' '}
                          <a
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              if (!loading) setShowTermsModal(true);
                            }}
                            style={{
                              color: 'var(--pink)',
                              textDecoration: 'underline',
                              cursor: loading ? 'not-allowed' : 'pointer',
                              pointerEvents: loading ? 'none' : 'auto'
                            }}
                          >
                            Terms & Conditions
                          </a>
                        </label>
                      </div>

                      <div style={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '10px'
                      }}>
                        <input
                          type="checkbox"
                          id="privacy-checkbox"
                          checked={acceptedPrivacy}
                          onChange={(e) => setAcceptedPrivacy(e.target.checked)}
                          disabled={loading}
                          style={{
                            marginTop: '3px',
                            minWidth: '16px',
                            width: '16px',
                            height: '16px',
                            cursor: loading ? 'not-allowed' : 'pointer',
                            flexShrink: 0
                          }}
                        />
                        <label
                          htmlFor="privacy-checkbox"
                          style={{
                            fontSize: '13px',
                            color: '#666',
                            lineHeight: '1.5',
                            cursor: loading ? 'not-allowed' : 'pointer',
                            flex: 1,
                            userSelect: 'none',
                            display: 'block'
                          }}
                        >
                          I agree to the{' '}
                          <a
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              if (!loading) setShowPrivacyModal(true);
                            }}
                            style={{
                              color: 'var(--pink)',
                              textDecoration: 'underline',
                              cursor: loading ? 'not-allowed' : 'pointer',
                              pointerEvents: loading ? 'none' : 'auto'
                            }}
                          >
                            Privacy Policy
                          </a>
                        </label>
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="btn-primary"
                    disabled={loading}
                    style={{
                      opacity: loading ? 0.6 : 1,
                      cursor: loading ? "not-allowed" : "pointer"
                    }}
                  >
                    {loading ? "Please wait..." : (isSignUp ? "Join Hinahon" : "Log In")}
                  </button>
                </form>

                <div className="divider">or</div>

                <button
                  className="btn-google"
                  onClick={signInWithGoogle}
                  disabled={loading}
                  aria-label="Continue with Google"
                >
                  <svg width="18" height="18" viewBox="0 0 18 18">
                    <path fill="#4285F4" d="M16.51 8H8.98v3h4.3c-.18 1-.74 1.48-1.6 2.04v2.01h2.6a7.8 7.8 0 0 0 2.38-5.88c0-.57-.05-.66-.15-1.18z"/>
                    <path fill="#34A853" d="M8.98 17c2.16 0 3.97-.72 5.3-1.94l-2.6-2a4.8 4.8 0 0 1-7.18-2.54H1.83v2.07A8 8 0 0 0 8.98 17z"/>
                    <path fill="#FBBC05" d="M4.5 10.52a4.8 4.8 0 0 1 0-3.04V5.41H1.83a8 8 0 0 0 0 7.18l2.67-2.07z"/>
                    <path fill="#EA4335" d="M8.98 4.18c1.17 0 2.23.4 3.06 1.2l2.3-2.3A8 8 0 0 0 1.83 5.4L4.5 7.49a4.77 4.77 0 0 1 4.48-3.3z"/>
                  </svg>
                  Continue with Google
                </button>

                <div style={{
                  textAlign: "center",
                  marginTop: "16px",
                  fontSize: "14px"
                }}>
                  <button
                    onClick={toggleAuthMode}
                    disabled={loading}
                    style={{
                      background: "none",
                      border: "none",
                      color: "var(--pink)",
                      cursor: loading ? "not-allowed" : "pointer",
                      textDecoration: "underline",
                      fontSize: "14px",
                      padding: "0",
                      opacity: loading ? 0.6 : 1
                    }}
                  >
                    {isSignUp
                      ? "Already with us? Sign in."
                      : "New here? Start the path to wellness today."
                    }
                  </button>
                </div>

                <div className="card-footer" style={{ marginTop: 12 }}>
                  {!isSignUp && (
                    <a
                      className="link-muted"
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                        setShowForgotPassword(true);
                      }}
                    >
                      Forgot Password?
                    </a>
                  )}
                  <a
                    className="link-muted"
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setShowHelpModal(true);
                    }}
                  >
                    Help
                  </a>
                </div>
              </div>{/* end fade-wrap */}
            </div>{/* end auth-card */}
          </div>{/* end auth-panel-inner */}
        </div>{/* end auth-panel */}
      </div>{/* end auth-container */}

      {showForgotPassword && (
        <div style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: "rgba(0, 0, 0, 0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 1000,
          padding: "20px"
        }}>
          <div style={{
            backgroundColor: "white",
            borderRadius: "12px",
            padding: "24px",
            maxWidth: "400px",
            width: "100%",
            boxShadow: "0 4px 20px rgba(0, 0, 0, 0.15)"
          }}>
            <h2 style={{
              margin: "0 0 8px 0",
              fontSize: "20px",
              fontWeight: 600
            }}>
              Reset Password
            </h2>
            <p style={{
              margin: "0 0 20px 0",
              fontSize: "14px",
              color: "#666"
            }}>
              Enter your email address and we'll send you a link to reset your password.
            </p>

            {resetMessage && (
              <div style={{
                backgroundColor: resetMessage.includes("✅") ? "#e8f5e9" : "#ffebee",
                color: resetMessage.includes("✅") ? "#2e7d32" : "#c62828",
                padding: "12px",
                borderRadius: "8px",
                fontSize: "13px",
                marginBottom: "16px",
                whiteSpace: "pre-line"
              }}>
                {resetMessage}
              </div>
            )}

            <form onSubmit={handlePasswordReset}>
              <div className="field">
                <input
                  type="email"
                  value={resetEmail}
                  onChange={(e) => setResetEmail(e.target.value)}
                  placeholder="Enter your email"
                  disabled={resetLoading}
                  required
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: "8px",
                    border: "1px solid #ddd",
                    fontSize: "14px"
                  }}
                />
              </div>

              <div style={{
                display: "flex",
                gap: "12px",
                marginTop: "20px"
              }}>
                <button
                  type="button"
                  onClick={() => {
                    setShowForgotPassword(false);
                    setResetEmail("");
                    setResetMessage("");
                  }}
                  disabled={resetLoading}
                  style={{
                    flex: 1,
                    padding: "12px",
                    borderRadius: "8px",
                    border: "1px solid #ddd",
                    backgroundColor: "white",
                    cursor: resetLoading ? "not-allowed" : "pointer",
                    fontSize: "14px",
                    fontWeight: 500,
                    opacity: resetLoading ? 0.6 : 1
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={resetLoading}
                  className="btn-primary"
                  style={{
                    flex: 1,
                    padding: "12px",
                    borderRadius: "8px",
                    border: "none",
                    cursor: resetLoading ? "not-allowed" : "pointer",
                    fontSize: "14px",
                    fontWeight: 500,
                    opacity: resetLoading ? 0.6 : 1
                  }}
                >
                  {resetLoading ? "Sending..." : "Send Reset Link"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <Modal
        isOpen={showTermsModal}
        onClose={() => setShowTermsModal(false)}
        title={<span className="modal-title">Terms & Conditions</span>}
      >
        <TermsAndConditions />
      </Modal>

      <Modal
        isOpen={showPrivacyModal}
        onClose={() => setShowPrivacyModal(false)}
        title="Privacy Policy"
      >
        <PrivacyPolicy />
      </Modal>

      <Modal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
        title="Contact Us"
      >
        <ContactInfo logomark={logomark} />
      </Modal>

      {/* Footer added as requested */}
      <footer style={{ position: 'fixed', bottom: 12, left: 0, right: 0, textAlign: 'center', zIndex: 1000, fontSize: '12px', color: '#fff', textShadow: '0 2px 6px rgba(0,0,0,0.6)', fontWeight: 500 }}>
        @2025 TEAM HINAHON | All Rights Reserved.
      </footer>
    </div>
  );
}
